# config.py

# Replace these values with your actual credentials
DATABASE_USER = "postgres"
DATABASE_PASSWORD = "admin123"
DATABASE_HOST = "localhost"
DATABASE_PORT = 5432
DATABASE_NAME = "qaqc"
