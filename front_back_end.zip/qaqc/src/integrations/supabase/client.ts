// filepath: /home/hc/ai-projects/qaqcflow2/qaqc/src/integrations/supabase/client.ts
import { Client } from "pg";

// PostgreSQL connection details
const DATABASE_USER = "postgres";
const DATABASE_PASSWORD = "admin123";
const DATABASE_HOST = "localhost";
const DATABASE_PORT = 5432;
const DATABASE_NAME = "qaqc";

// Create a PostgreSQL client
const client = new Client({
  user: DATABASE_USER,
  host: DATABASE_HOST,
  database: DATABASE_NAME,
  password: DATABASE_PASSWORD,
  port: DATABASE_PORT,
});

// Connect to the PostgreSQL database
client.connect()
  .then(() => console.log("Connected to PostgreSQL"))
  .catch(err => console.error("Connection error", err.stack));

// Example query function
export async function queryDatabase(query: string) {
  try {
    const res = await client.query(query);
    return res.rows;
  } catch (error) {
    console.error("Database query error:", error);
    throw error;
  }
}

// Export the client as `supabase` so that existing imports work
export const supabase = client;

// Close the connection when done
process.on('exit', () => {
  client.end();
});
