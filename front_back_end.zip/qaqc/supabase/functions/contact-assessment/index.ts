// filepath: /home/hc/ai-projects/qaqcflow2/qaqc/supabase/functions/contact-assessment/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Client } from "pg";
import { assess_complaints, assess_vulnerability, store_assessment_results } from './assessment.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// PostgreSQL connection details
const DATABASE_USER = "postgres";
const DATABASE_PASSWORD = "admin123";
const DATABASE_HOST = "localhost";
const DATABASE_PORT = 5432;
const DATABASE_NAME = "qaqc";

// Create a PostgreSQL client
const client = new Client({
  user: DATABASE_USER,
  host: DATABASE_HOST,
  database: DATABASE_NAME,
  password: DATABASE_PASSWORD,
  port: DATABASE_PORT,
});

// Connect to the PostgreSQL database
client.connect()
  .then(() => console.log("Connected to PostgreSQL"))
  .catch(err => console.error("Connection error", err.stack));

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log("Contact assessment function called");
    const { contact_id } = await req.json();

    if (!contact_id) {
      throw new Error('Contact ID is required');
    }

    console.log("Fetching conversation transcript for contact:", contact_id);
    // Fetch conversation transcript from PostgreSQL
    const query = 'SELECT * FROM conversation_transcripts WHERE contact_id = $1';
    const result = await client.query(query, [contact_id]);

    if (result.rows.length === 0) {
      throw new Error('No conversation transcript found for contact ID');
    }

    const transcript = result.rows[0];

    // Perform assessments
    const complaintsAssessment = assess_complaints(transcript);
    const vulnerabilityAssessment = assess_vulnerability(transcript);

    // Store assessment results
    await store_assessment_results(contact_id, complaintsAssessment, vulnerabilityAssessment);

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});

// Close the connection when done
process.on('exit', () => {
  client.end();
});